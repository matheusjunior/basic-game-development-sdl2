#ifndef CONSTS_H_
#define CONSTS_H_

#define SCREEN_HEIGHT  750
#define SCREEN_WIDTH   1000
#define RECT_WIDTH		35
#define RECT_HEIGHT		35
#define MENU_UP			 1
#define MENU_DOWN       -1
#define PI 3.14159265

#endif // consts
